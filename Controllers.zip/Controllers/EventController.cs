﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventEaseProject.Data;
using EventEaseProject.Models;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;

namespace EventEaseProject.Controllers
{
    public class EventController : Controller
    {
        private readonly EEDbContext _context;
        private readonly ILogger<EventController> _logger;

        public EventController(EEDbContext context, ILogger<EventController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: Event
        public async Task<IActionResult> Index(string searchTerm)
        {
            try
            {
                var events = _context.Events.Include(e => e.Venue).AsQueryable();
                if (!string.IsNullOrEmpty(searchTerm))
                {
                    searchTerm = searchTerm.ToLower().Trim();
                    events = events.Where(e => e.EventId.ToString().Contains(searchTerm) ||
                                            (e.EventDescription != null && e.EventDescription.ToLower().Contains(searchTerm)) ||
                                            (e.Venue != null && e.Venue.VenueName != null && e.Venue.VenueName.ToLower().Contains(searchTerm)));
                }
                var results = await events.OrderBy(e => e.EventDate).ToListAsync();
                ViewBag.SearchTerm = searchTerm;
                TempData["SearchMessage"] = results.Any() ? null : "No events found matching the search term.";
                return View(results);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving events.");
                TempData["ErrorMessage"] = $"Error retrieving events: {ex.Message}";
                return View(new List<Event>());
            }
        }

        // GET: Event/Create
        public async Task<IActionResult> Create()
        {
            ViewBag.VenueId = new SelectList(await _context.Venues.ToListAsync(), "VenueId", "VenueName");
            return View();
        }

        // POST: Event/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EventDate,EventDescription,VenueId")] Event eventItem)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var venue = await _context.Venues.FindAsync(eventItem.VenueId);
                    if (eventItem.VenueId.HasValue && venue == null)
                    {
                        ModelState.AddModelError("VenueId", "Selected venue is invalid.");
                    }
                    else
                    {
                        eventItem.Venue = venue;
                        _context.Add(eventItem);
                        await _context.SaveChangesAsync();
                        TempData["SuccessMessage"] = "Event created successfully.";
                        return RedirectToAction(nameof(Index));
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error creating event.");
                    TempData["ErrorMessage"] = $"Error creating event: {ex.Message}";
                }
            }
            ViewBag.VenueId = new SelectList(await _context.Venues.ToListAsync(), "VenueId", "VenueName", eventItem.VenueId);
            return View(eventItem);
        }

        // GET: Event/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || !await EventExists(id.Value)) return NotFound();
            var eventItem = await _context.Events
                .Include(e => e.Venue)
                .FirstOrDefaultAsync(m => m.EventId == id);
            if (eventItem == null) return NotFound();
            return View(eventItem);
        }

        // GET: Event/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || !await EventExists(id.Value)) return NotFound();
            var eventItem = await _context.Events
                .Include(e => e.Venue)
                .FirstOrDefaultAsync(m => m.EventId == id);
            if (eventItem == null) return NotFound();
            ViewBag.VenueId = new SelectList(await _context.Venues.ToListAsync(), "VenueId", "VenueName", eventItem.VenueId);
            return View(eventItem);
        }

        // POST: Event/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EventId,EventDate,EventDescription,VenueId")] Event eventItem)
        {
            if (id != eventItem.EventId) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    var venue = await _context.Venues.FindAsync(eventItem.VenueId);
                    if (eventItem.VenueId.HasValue && venue == null)
                    {
                        ModelState.AddModelError("VenueId", "Selected venue is invalid.");
                    }
                    else
                    {
                        eventItem.Venue = venue;
                        _context.Update(eventItem);
                        await _context.SaveChangesAsync();
                        TempData["SuccessMessage"] = "Event updated successfully.";
                        return RedirectToAction(nameof(Index));
                    }
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await EventExists(eventItem.EventId)) return NotFound();
                    throw;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error updating event.");
                    TempData["ErrorMessage"] = $"Error updating event: {ex.Message}";
                }
            }
            ViewBag.VenueId = new SelectList(await _context.Venues.ToListAsync(), "VenueId", "VenueName", eventItem.VenueId);
            return View(eventItem);
        }

        // GET: Event/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || !await EventExists(id.Value)) return NotFound();
            var eventItem = await _context.Events
                .Include(e => e.Venue)
                .FirstOrDefaultAsync(m => m.EventId == id);
            if (eventItem == null) return NotFound();
            return View(eventItem);
        }

        // POST: Event/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var eventItem = await _context.Events.FindAsync(id);
                if (eventItem == null) return RedirectToAction(nameof(Index));
                _context.Events.Remove(eventItem);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Event deleted successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting event.");
                TempData["ErrorMessage"] = $"Error deleting event: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }

        private async Task<bool> EventExists(int id)
        {
            return await _context.Events.AnyAsync(e => e.EventId == id);
        }
    }
}