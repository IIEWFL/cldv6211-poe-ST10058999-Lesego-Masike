using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventEaseProject.Data;
using EventEaseProject.Models;
using Microsoft.Extensions.Logging;

namespace EventEaseProject.Controllers
{
    public class HomeController : Controller
    {
        private readonly EEDbContext _context;
        private readonly ILogger<HomeController> _logger;

        public HomeController(EEDbContext context, ILogger<HomeController> logger)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public IActionResult Index()
        {
            try
            {
                ViewBag.CurrentDateTime = DateTime.Now.ToString("HH:mm tt zzz on dddd, MMMM dd, yyyy");
                return View();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading home page.");
                TempData["ErrorMessage"] = $"Error loading home page: {ex.Message}";
                return View();
            }
        }

        public async Task<IActionResult> Search(string searchTerm)
        {
            try
            {
                var query = _context.BookingViews.AsQueryable();

                if (!string.IsNullOrEmpty(searchTerm))
                {
                    searchTerm = searchTerm.ToLower().Trim();
                    query = query.Where(b => b.BookingID.ToString().Contains(searchTerm) ||
                                          (b.EventDescription != null && b.EventDescription.ToLower().Contains(searchTerm)) ||
                                          (b.VenueName != null && b.VenueName.ToLower().Contains(searchTerm)) ||
                                          (b.VenueLocation != null && b.VenueLocation.ToLower().Contains(searchTerm)));
                }

                var results = await query.OrderBy(b => b.BookingDate).ToListAsync();
                ViewBag.SearchTerm = searchTerm;
                TempData["SearchMessage"] = results.Any() ? null : "No bookings found matching the search term.";
                return View(results ?? new List<BookingView>());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error searching bookings.");
                TempData["ErrorMessage"] = $"Error searching bookings: {ex.Message}";
                return View(new List<BookingView>());
            }
        }

        public IActionResult Privacy()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading privacy page.");
                TempData["ErrorMessage"] = $"Error loading privacy page: {ex.Message}";
                return View();
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            try
            {
                return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading error page.");
                TempData["ErrorMessage"] = $"Error loading error page: {ex.Message}";
                return View(new ErrorViewModel { RequestId = "Unknown" });
            }
        }
    }
}