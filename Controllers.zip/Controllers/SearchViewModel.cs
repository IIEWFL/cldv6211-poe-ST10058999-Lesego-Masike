﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EventEaseProject.Models
{
    public class SearchViewModel
    {
        public List<Venue> Venues { get; set; } = new List<Venue>(); // Initialized to avoid CS8618
        public List<Event> Events { get; set; } = new List<Event>(); // Initialized to avoid CS8618
        public List<Booking> Bookings { get; set; } = new List<Booking>(); // Initialized to avoid CS8618

        [Display(Name = "Search Term")]
        public string SearchTerm { get; set; }

        [Display(Name = "Availability")]
        public string Availability { get; set; } = "All";

        [Display(Name = "Event Type")]
        public string EventType { get; set; } = "All";

        [Display(Name = "From Date")]
        [DataType(DataType.Date)]
        public DateTime? FromDate { get; set; }

        [Display(Name = "To Date")]
        [DataType(DataType.Date)]
        public DateTime? ToDate { get; set; }
    }
}