﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventEaseProject.Data;
using EventEaseProject.Models;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace EventEaseProject.Controllers
{
    public class VenuesController : Controller
    {
        private readonly EEDbContext _context;
        private readonly ILogger<VenuesController> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public VenuesController(EEDbContext context, ILogger<VenuesController> logger, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _logger = logger;
            _webHostEnvironment = webHostEnvironment;
        }

        // GET: Venues
        public async Task<IActionResult> Index(string searchTerm)
        {
            try
            {
                var venues = _context.Venues.AsQueryable();
                if (!string.IsNullOrEmpty(searchTerm))
                {
                    searchTerm = searchTerm.ToLower().Trim();
                    venues = venues.Where(v => v.VenueId.ToString().Contains(searchTerm) ||
                                            (v.VenueName != null && v.VenueName.ToLower().Contains(searchTerm)) ||
                                            (v.VenueLocation != null && v.VenueLocation.ToLower().Contains(searchTerm)));
                }
                var results = await venues.OrderBy(v => v.VenueName).ToListAsync();
                ViewBag.SearchTerm = searchTerm;
                TempData["SearchMessage"] = results.Any() ? null : "No venues found matching the search term.";
                return View(results);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving venues.");
                TempData["ErrorMessage"] = $"Error retrieving venues: {ex.Message}";
                return View(new List<Venue>());
            }
        }

        // GET: Venues/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Venues/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VenueName,VenueLocation,VenueCapacity,VenueImage")] Venue venue, IFormFile VenueImage)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (VenueImage != null && VenueImage.Length > 0)
                    {
                        var imagesDir = Path.Combine(_webHostEnvironment.WebRootPath, "images");
                        if (!Directory.Exists(imagesDir))
                        {
                            Directory.CreateDirectory(imagesDir);
                        }
                        var filePath = Path.Combine(imagesDir, Guid.NewGuid().ToString() + Path.GetExtension(VenueImage.FileName));
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await VenueImage.CopyToAsync(stream);
                        }
                        venue.VenueImage = $"/images/{Path.GetFileName(filePath)}";
                    }
                    _context.Venues.Add(venue);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Venue created successfully.";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error creating venue.");
                    TempData["ErrorMessage"] = $"Error creating venue: {ex.Message}";
                }
            }
            return View(venue);
        }

        // GET: Venues/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || !await VenueExists(id.Value)) return NotFound();
            var venue = await _context.Venues.FirstOrDefaultAsync(m => m.VenueId == id);
            if (venue == null) return NotFound();
            return View(venue);
        }

        // GET: Venues/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || !await VenueExists(id.Value)) return NotFound();
            var venue = await _context.Venues.FirstOrDefaultAsync(m => m.VenueId == id);
            if (venue == null) return NotFound();
            return View(venue);
        }

        // POST: Venues/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VenueId,VenueName,VenueLocation,VenueCapacity,VenueImage")] Venue venue, IFormFile VenueImage)
        {
            if (id != venue.VenueId) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    if (VenueImage != null && VenueImage.Length > 0)
                    {
                        var imagesDir = Path.Combine(_webHostEnvironment.WebRootPath, "images");
                        if (!Directory.Exists(imagesDir))
                        {
                            Directory.CreateDirectory(imagesDir);
                        }
                        var filePath = Path.Combine(imagesDir, Guid.NewGuid().ToString() + Path.GetExtension(VenueImage.FileName));
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await VenueImage.CopyToAsync(stream);
                        }
                        venue.VenueImage = $"/images/{Path.GetFileName(filePath)}";
                    }
                    _context.Update(venue);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Venue updated successfully.";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await VenueExists(venue.VenueId)) return NotFound();
                    throw;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error updating venue.");
                    TempData["ErrorMessage"] = $"Error updating venue: {ex.Message}";
                }
            }
            return View(venue);
        }

        // GET: Venues/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || !await VenueExists(id.Value)) return NotFound();
            var venue = await _context.Venues.FirstOrDefaultAsync(m => m.VenueId == id);
            if (venue == null) return NotFound();
            return View(venue);
        }

        // POST: Venues/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var venue = await _context.Venues.FindAsync(id);
                if (venue == null) return RedirectToAction(nameof(Index));
                _context.Venues.Remove(venue);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Venue deleted successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting venue.");
                TempData["ErrorMessage"] = $"Error deleting venue: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }

        private async Task<bool> VenueExists(int id)
        {
            return await _context.Venues.AnyAsync(v => v.VenueId == id);
        }
    }
}