﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventEaseProject.Data;
using EventEaseProject.Models;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;

namespace EventEaseProject.Controllers
{
    public class BookingsController : Controller
    {
        private readonly EEDbContext _context;
        private readonly ILogger<BookingsController> _logger;

        public BookingsController(EEDbContext context, ILogger<BookingsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: Bookings
        public async Task<IActionResult> Index(string searchTerm)
        {
            try
            {
                var bookings = _context.Bookings.Include(b => b.Event).Include(b => b.Venue).AsQueryable();
                if (!string.IsNullOrEmpty(searchTerm))
                {
                    searchTerm = searchTerm.ToLower().Trim();
                    bookings = bookings.Where(b => b.BookingId.ToString().Contains(searchTerm) ||
                                                (b.Event != null && b.Event.EventDescription != null && b.Event.EventDescription.ToLower().Contains(searchTerm)) ||
                                                (b.Venue != null && b.Venue.VenueName != null && b.Venue.VenueName.ToLower().Contains(searchTerm)));
                }
                var results = await bookings.OrderBy(b => b.BookingDate).ToListAsync();
                ViewBag.SearchTerm = searchTerm;
                TempData["SearchMessage"] = results.Any() ? null : "No bookings found matching the search term.";
                return View(results);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving bookings.");
                TempData["ErrorMessage"] = $"Error retrieving bookings: {ex.Message}";
                return View(new List<Booking>());
            }
        }

        // GET: Bookings/Create
        public async Task<IActionResult> Create()
        {
            ViewBag.EventId = new SelectList(await _context.Events.ToListAsync(), "EventId", "EventDescription");
            ViewBag.VenueId = new SelectList(await _context.Venues.ToListAsync(), "VenueId", "VenueName");
            return View();
        }

        // POST: Bookings/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EventId,VenueId,BookingDate")] Booking booking)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var eventExists = await _context.Events.AnyAsync(e => e.EventId == booking.EventId);
                    var venueExists = await _context.Venues.AnyAsync(v => v.VenueId == booking.VenueId);
                    if (!eventExists) ModelState.AddModelError("EventId", "Selected event is invalid.");
                    if (!venueExists) ModelState.AddModelError("VenueId", "Selected venue is invalid.");
                    if (eventExists && venueExists)
                    {
                        _context.Add(booking);
                        await _context.SaveChangesAsync();
                        TempData["SuccessMessage"] = "Booking created successfully.";
                        return RedirectToAction(nameof(Index));
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error creating booking.");
                    TempData["ErrorMessage"] = $"Error creating booking: {ex.Message}";
                }
            }
            ViewBag.EventId = new SelectList(await _context.Events.ToListAsync(), "EventId", "EventDescription", booking.EventId);
            ViewBag.VenueId = new SelectList(await _context.Venues.ToListAsync(), "VenueId", "VenueName", booking.VenueId);
            return View(booking);
        }

        // GET: Bookings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || !await BookingExists(id.Value)) return NotFound();
            var booking = await _context.Bookings
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(m => m.BookingId == id);
            if (booking == null) return NotFound();
            return View(booking);
        }

        // GET: Bookings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || !await BookingExists(id.Value)) return NotFound();
            var booking = await _context.Bookings
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(m => m.BookingId == id);
            if (booking == null) return NotFound();
            ViewBag.EventId = new SelectList(await _context.Events.ToListAsync(), "EventId", "EventDescription", booking.EventId);
            ViewBag.VenueId = new SelectList(await _context.Venues.ToListAsync(), "VenueId", "VenueName", booking.VenueId);
            return View(booking);
        }

        // POST: Bookings/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookingId,EventId,VenueId,BookingDate")] Booking booking)
        {
            if (id != booking.BookingId) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    var eventExists = await _context.Events.AnyAsync(e => e.EventId == booking.EventId);
                    var venueExists = await _context.Venues.AnyAsync(v => v.VenueId == booking.VenueId);
                    if (!eventExists) ModelState.AddModelError("EventId", "Selected event is invalid.");
                    if (!venueExists) ModelState.AddModelError("VenueId", "Selected venue is invalid.");
                    if (eventExists && venueExists)
                    {
                        _context.Update(booking);
                        await _context.SaveChangesAsync();
                        TempData["SuccessMessage"] = "Booking updated successfully.";
                        return RedirectToAction(nameof(Index));
                    }
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await BookingExists(booking.BookingId)) return NotFound();
                    throw;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error updating booking.");
                    TempData["ErrorMessage"] = $"Error updating booking: {ex.Message}";
                }
            }
            ViewBag.EventId = new SelectList(await _context.Events.ToListAsync(), "EventId", "EventDescription", booking.EventId);
            ViewBag.VenueId = new SelectList(await _context.Venues.ToListAsync(), "VenueId", "VenueName", booking.VenueId);
            return View(booking);
        }

        // GET: Bookings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || !await BookingExists(id.Value)) return NotFound();
            var booking = await _context.Bookings
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(m => m.BookingId == id);
            if (booking == null) return NotFound();
            return View(booking);
        }

        // POST: Bookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var booking = await _context.Bookings.FindAsync(id);
                if (booking == null) return RedirectToAction(nameof(Index));
                _context.Bookings.Remove(booking);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Booking deleted successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting booking.");
                TempData["ErrorMessage"] = $"Error deleting booking: {ex.Message}";
                return RedirectToAction(nameof(Index));
            }
        }

        private async Task<bool> BookingExists(int id)
        {
            return await _context.Bookings.AnyAsync(b => b.BookingId == id);
        }
    }
}