﻿using Microsoft.EntityFrameworkCore;
using EventEaseProject.Models;
using System;

namespace EventEaseProject.Data
{
    public class EEDbContext : DbContext
    {
        public EEDbContext(DbContextOptions<EEDbContext> options) : base(options)
        {
        }

        public DbSet<Event> Events { get; set; }
        public DbSet<Venue> Venues { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<BookingView> BookingViews { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Event Configuration
            modelBuilder.Entity<Event>(entity =>
            {
                entity.HasKey(e => e.EventId);
                entity.Property(e => e.EventDate).HasColumnType("datetime").IsRequired();
                entity.Property(e => e.EventDescription).HasMaxLength(500).IsRequired();
                entity.Property(e => e.VenueId).IsRequired(false); // Nullable for flexibility
                entity.HasOne(e => e.Venue)
                      .WithMany(v => v.Events)
                      .HasForeignKey(e => e.VenueId)
                      .OnDelete(DeleteBehavior.Restrict); // Prevent cascade delete to avoid orphaned events
                entity.HasMany(e => e.Bookings)
                      .WithOne(b => b.Event)
                      .HasForeignKey(b => b.EventId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // Venue Configuration
            modelBuilder.Entity<Venue>(entity =>
            {
                entity.HasKey(v => v.VenueId);
                entity.Property(v => v.VenueName).HasMaxLength(250).IsRequired();
                entity.Property(v => v.VenueLocation).HasMaxLength(250).IsRequired();
                entity.Property(v => v.VenueCapacity).IsRequired();
                entity.Property(v => v.VenueImage).IsRequired(false); // Allow null for venues without images
                entity.HasIndex(v => new { v.VenueName, v.VenueLocation }).IsUnique();
                entity.HasMany(v => v.Bookings)
                      .WithOne(b => b.Venue)
                      .HasForeignKey(b => b.VenueId)
                      .OnDelete(DeleteBehavior.Cascade);
                entity.HasMany(v => v.Events)
                      .WithOne(e => e.Venue)
                      .HasForeignKey(e => e.VenueId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // Booking Configuration
            modelBuilder.Entity<Booking>(static entity =>
            {
                entity.HasKey(b => b.BookingId);
                entity.Property(b => b.EventId).IsRequired();
                entity.Property(b => b.VenueId).IsRequired();
                entity.Property(b => b.BookingDate).HasColumnType("datetime").IsRequired();
                entity.HasIndex(b => new { b.EventId, b.VenueId, b.BookingDate }).IsUnique()
                      .HasName("IX_UniqueBooking"); // Named index for clarity
                entity.HasOne(b => b.Event)
                      .WithMany(e => e.Bookings)
                      .HasForeignKey(b => b.EventId)
                      .OnDelete(DeleteBehavior.Cascade);
                entity.HasOne(b => b.Venue)
                      .WithMany(v => v.Bookings)
                      .HasForeignKey(b => b.VenueId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // BookingView Configuration
            modelBuilder.Entity<BookingView>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("BookingView");
                entity.Property(b => b.BookingID).HasColumnName("BookingId");
                entity.Property(b => b.VenueName).HasColumnName("VenueName");
                entity.Property(b => b.VenueLocation).HasColumnName("VenueLocation");
                entity.Property(b => b.VenueCapacity).HasColumnName("VenueCapacity");
                entity.Property(b => b.EventDate).HasColumnName("EventDate");
                entity.Property(b => b.EventDescription).HasColumnName("EventDescription");
                entity.Property(b => b.BookingDate).HasColumnName("BookingDate");
            });

            // Seed Data
            modelBuilder.Entity<Venue>().HasData(
                new Venue { VenueId = 1, VenueName = "Main Auditorium", VenueLocation = "City Center", VenueCapacity = 500, VenueImage = "https://example.com/main_auditorium.jpg" },
                new Venue { VenueId = 2, VenueName = "Conference Hall A", VenueLocation = "Downtown", VenueCapacity = 150, VenueImage = "https://example.com/conference_hall_a.jpg" }
            );

            modelBuilder.Entity<Event>().HasData(
                new Event { EventId = 1, EventDate = DateTime.Parse("2025-06-21"), EventDescription = "Tech Conference 2025", VenueId = 1 },
                new Event { EventId = 2, EventDate = DateTime.Parse("2025-06-22"), EventDescription = "Business Seminar", VenueId = 2 }
            );

            modelBuilder.Entity<Booking>().HasData(
                new Booking { BookingId = 1, EventId = 1, VenueId = 1, BookingDate = DateTime.Parse("2025-06-21 14:30:00") },
                new Booking { BookingId = 2, EventId = 2, VenueId = 2, BookingDate = DateTime.Parse("2025-06-22 09:00:00") }
            );
        }
    }
}