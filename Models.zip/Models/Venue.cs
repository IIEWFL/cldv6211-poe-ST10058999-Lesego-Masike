﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EventEaseProject.Models
{
    public class Venue
    {
        public int VenueId { get; set; }

        [Required]
        [StringLength(250)]
        public required string VenueName { get; set; }

        [Required]
        [StringLength(250)]
        public required string VenueLocation { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int VenueCapacity { get; set; }

        public string? VenueImage { get; set; } // Changed to nullable to match EEDbContext

        public ICollection<Booking> Bookings { get; set; } = new List<Booking>(); // Initialized to avoid CS8618

        public ICollection<Event> Events { get; set; } = new List<Event>(); // Added for one-to-many relationship with Events

        public string ImageUrl => VenueImage; // Added for views
    }
}