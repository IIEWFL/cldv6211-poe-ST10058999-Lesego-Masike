using System;

namespace EventEaseProject.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        public string? ErrorMessage { get; set; }

        public DateTime? ErrorTimestamp { get; set; } = DateTime.Now; // Default to current time if not set
    }
}