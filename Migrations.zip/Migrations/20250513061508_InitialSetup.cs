﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventEaseProject.Migrations
{
    /// <inheritdoc />
    public partial class InitialSetup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Events",
                columns: table => new
                {
                    EventId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VenueId = table.Column<int>(type: "int", nullable: true),
                    EventName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    EventDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    EventDescription = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Events", x => x.EventId);
                    table.ForeignKey(
                        name: "FK_Events_Venues_VenueId",
                        column: x => x.VenueId,
                        principalTable: "Venues",
                        principalColumn: "VenueId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Venues",
                columns: table => new
                {
                    VenueId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VenueName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    VenueLocation = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    VenueCapacity = table.Column<int>(type: "int", nullable: false),
                    VenueImage = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Venues", x => x.VenueId);
                });

            migrationBuilder.CreateTable(
                name: "Bookings",
                columns: table => new
                {
                    BookingId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EventId = table.Column<int>(type: "int", nullable: false),
                    VenueId = table.Column<int>(type: "int", nullable: false),
                    BookingDate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bookings", x => x.BookingId);
                    table.ForeignKey(
                        name: "FK_Bookings_Events_EventId",
                        column: x => x.EventId,
                        principalTable: "Events",
                        principalColumn: "EventId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Bookings_Venues_VenueId",
                        column: x => x.VenueId,
                        principalTable: "Venues",
                        principalColumn: "VenueId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Events_VenueId",
                table: "Events",
                column: "VenueId");

            migrationBuilder.CreateIndex(
                name: "IX_Venues_VenueName_VenueLocation",
                table: "Venues",
                columns: new[] { "VenueName", "VenueLocation" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Bookings_EventId_VenueId_BookingDate",
                table: "Bookings",
                columns: new[] { "EventId", "VenueId", "BookingDate" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Bookings_VenueId",
                table: "Bookings",
                column: "VenueId");

            // Seed Data
            migrationBuilder.InsertData(
                table: "Venues",
                columns: new[] { "VenueId", "VenueName", "VenueLocation", "VenueCapacity", "VenueImage" },
                values: new object[,]
                {
                    { 1, "Main Auditorium", "City Center", 500, "https://example.com/main_auditorium.jpg" },
                    { 2, "Conference Hall A", "Downtown", 150, "https://example.com/conference_hall_a.jpg" }
                });

            migrationBuilder.InsertData(
                table: "Events",
                columns: new[] { "EventId", "VenueId", "EventName", "EventDate", "EventDescription" },
                values: new object[,]
                {
                    { 1, 1, "Tech Conference 2025", new DateTime(2025, 6, 21, 14, 30, 0), "Tech Conference 2025 focusing on AI and Cloud Computing" },
                    { 2, 2, "Business Seminar", new DateTime(2025, 6, 22, 9, 0, 0), "Business Seminar on startup growth strategies" }
                });

            migrationBuilder.InsertData(
                table: "Bookings",
                columns: new[] { "BookingId", "EventId", "VenueId", "BookingDate" },
                values: new object[,]
                {
                    { 1, 1, 1, new DateTime(2025, 6, 21, 14, 30, 0) },
                    { 2, 2, 2, new DateTime(2025, 6, 22, 9, 0, 0) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Bookings");

            migrationBuilder.DropTable(
                name: "Events");

            migrationBuilder.DropTable(
                name: "Venues");
        }
    }
}