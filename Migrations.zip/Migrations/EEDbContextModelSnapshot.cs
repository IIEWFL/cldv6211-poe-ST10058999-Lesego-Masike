﻿using System;
using EventEaseProject.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

#nullable disable

namespace EventEaseProject.Migrations
{
    [DbContext(typeof(EEDbContext))]
    partial class EEDbContextModelSnapshot : ModelSnapshot
    {
        protected override void BuildModel(ModelBuilder modelBuilder)
        {
#pragma warning disable 612, 618
            modelBuilder
                .HasAnnotation("ProductVersion", "9.0.4")
                .HasAnnotation("Relational:MaxIdentifierLength", 128);

            SqlServerModelBuilderExtensions.UseIdentityColumns(modelBuilder);

            modelBuilder.Entity("EventEaseProject.Models.Booking", b =>
            {
                b.Property<int>("BookingId")
                    .ValueGeneratedOnAdd()
                    .HasColumnType("int");

                SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("BookingId"));

                b.Property<DateTime>("BookingDate")
                    .HasColumnType("datetime");

                b.Property<int>("EventId")
                    .HasColumnType("int");

                b.Property<int>("VenueId")
                    .HasColumnType("int");

                b.HasKey("BookingId");

                b.HasIndex("VenueId");

                b.HasIndex("EventId", "VenueId", "BookingDate")
                    .IsUnique();

                b.ToTable("Bookings");
            });

            modelBuilder.Entity("EventEaseProject.Models.BookingView", b =>
            {
                b.Property<DateTime>("BookingDate")
                    .HasColumnType("datetime2");

                b.Property<int>("BookingID")
                    .HasColumnType("int");

                b.Property<DateTime>("EventDate")
                    .HasColumnType("datetime2");

                b.Property<string>("EventDescription")
                    .IsRequired()
                    .HasColumnType("nvarchar(max)");

                b.Property<int>("VenueCapacity")
                    .HasColumnType("int");

                b.Property<string>("VenueLocation")
                    .IsRequired()
                    .HasColumnType("nvarchar(max)");

                b.Property<string>("VenueName")
                    .IsRequired()
                    .HasColumnType("nvarchar(max)");

                b.ToTable((string)null);

                b.ToView("BookingView", (string)null);
            });

            modelBuilder.Entity("EventEaseProject.Models.Event", b =>
            {
                b.Property<int>("EventId")
                    .ValueGeneratedOnAdd()
                    .HasColumnType("int");

                SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("EventId"));

                b.Property<DateTime>("EventDate")
                    .HasColumnType("datetime");

                b.Property<string>("EventDescription")
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnType("nvarchar(500)");

                b.Property<int?>("VenueId")
                    .HasColumnType("int");

                b.HasKey("EventId");

                b.HasIndex("VenueId");

                b.ToTable("Events");
            });

            modelBuilder.Entity("EventEaseProject.Models.Venue", b =>
            {
                b.Property<int>("VenueId")
                    .ValueGeneratedOnAdd()
                    .HasColumnType("int");

                SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("VenueId"));

                b.Property<int>("VenueCapacity")
                    .HasColumnType("int");

                b.Property<string>("VenueImage")
                    .HasColumnType("nvarchar(max)"); // Changed to nullable

                b.Property<string>("VenueLocation")
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnType("nvarchar(250)");

                b.Property<string>("VenueName")
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnType("nvarchar(250)");

                b.HasKey("VenueId");

                b.HasIndex("VenueName", "VenueLocation")
                    .IsUnique();

                b.ToTable("Venues");
            });

            modelBuilder.Entity("EventEaseProject.Models.Booking", b =>
            {
                b.HasOne("EventEaseProject.Models.Event", "Event")
                    .WithMany("Bookings")
                    .HasForeignKey("EventId")
                    .OnDelete(DeleteBehavior.Cascade)
                    .IsRequired();

                b.HasOne("EventEaseProject.Models.Venue", "Venue")
                    .WithMany("Bookings")
                    .HasForeignKey("VenueId")
                    .OnDelete(DeleteBehavior.Cascade)
                    .IsRequired();

                b.Navigation("Event");

                b.Navigation("Venue");
            });

            modelBuilder.Entity("EventEaseProject.Models.Event", b =>
            {
                b.HasOne("EventEaseProject.Models.Venue", "Venue")
                    .WithMany("Events")
                    .HasForeignKey("VenueId")
                    .OnDelete(DeleteBehavior.Restrict);

                b.Navigation("Bookings");

                b.Navigation("Venue");
            });

            modelBuilder.Entity("EventEaseProject.Models.Venue", b =>
            {
                b.Navigation("Bookings");

                b.Navigation("Events");
            });
#pragma warning restore 612, 618
        }
    }
}