﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace EventEaseProject.Migrations
{
    /// <inheritdoc />
    public partial class AddSeedData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Events",
                columns: new[] { "EventId", "VenueId", "EventDate", "EventDescription", "EventName" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2025, 6, 15, 9, 0, 0), "A conference for tech enthusiasts focusing on AI innovations.", "Tech Conference 2025" },
                    { 2, 2, new DateTime(2025, 7, 20, 14, 0, 0), "A weekend of live music and performances.", "Music Festival" }
                });

            migrationBuilder.InsertData(
                table: "Venues",
                columns: new[] { "VenueId", "VenueCapacity", "VenueLocation", "VenueName", "VenueImage" },
                values: new object[,]
                {
                    { 1, 500, "Downtown", "City Hall", "https://example.com/city_hall.jpg" },
                    { 2, 2000, "Suburbs", "Open Park", "https://example.com/open_park.jpg" }
                });

            migrationBuilder.InsertData(
                table: "Bookings",
                columns: new[] { "BookingId", "EventId", "VenueId", "BookingDate" },
                values: new object[] { 1, 1, 1, new DateTime(2025, 6, 15, 9, 0, 0) });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Bookings",
                keyColumn: "BookingId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Events",
                keyColumn: "EventId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Venues",
                keyColumn: "VenueId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Events",
                keyColumn: "EventId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Venues",
                keyColumn: "VenueId",
                keyValue: 1);
        }
    }
}